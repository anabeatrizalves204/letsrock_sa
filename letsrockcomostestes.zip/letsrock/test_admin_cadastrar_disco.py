import unittest
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager


class TestAdminCadastrarDisco(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))
        cls.driver.maximize_window()
        cls.wait = WebDriverWait(cls.driver, 10)
        cls.base_url = "http://localhost/letsrock"

    @classmethod
    def tearDownClass(cls):
        cls.driver.quit()

    def fazer_login_admin(self):
        driver = self.driver
        driver.get(f"{self.base_url}/login.php")

        #espera pelo campo email
        self.wait.until(EC.presence_of_element_located((By.NAME, "email")))

        #preenche com o login do admin
        driver.find_element(By.NAME, "email").send_keys("admin@letsrock.com")
        driver.find_element(By.NAME, "senha").send_keys("admin123")

        #botão para entrar
        driver.find_element(By.CLASS_NAME, "submit-btn").click()

        #espera pela url
        self.wait.until(EC.url_contains("admin_dashboard.php"))

    def test_cadastrar_disco_sucesso(self):
        self.fazer_login_admin()
        driver = self.driver

        #vai para a página de cadastro de disco
        driver.get(f"{self.base_url}/admin_cadastrar_disco.php")

        #espera pelo formulário
        self.wait.until(EC.presence_of_element_located((By.NAME, "titulo")))

        #preenche o formulário de cadastro
        driver.find_element(By.NAME, "titulo").send_keys("Teste Disco")
        driver.find_element(By.NAME, "artista").send_keys("Artista Teste")
        driver.find_element(By.NAME, "ano").send_keys("2023")
        driver.find_element(By.NAME, "gravadora").send_keys("Gravadora Teste")
        driver.find_element(By.NAME, "genero").send_keys("Rock")
        driver.find_element(By.NAME, "estilo").send_keys("Hard Rock")
        driver.find_element(By.NAME, "preco").send_keys("49,90")
        driver.find_element(By.NAME, "descricao").send_keys("Descrição do disco teste.")
        driver.find_element(By.NAME, "pais").send_keys("Brasil")
        driver.find_element(By.NAME, "estoque").clear()
        driver.find_element(By.NAME, "estoque").send_keys("10")

        #imagem
        caminho_imagem = r"C:\xampp\htdocs\letsrock\imagens\logo.png"
        driver.find_element(By.NAME, "imagem").send_keys(caminho_imagem)

        #submit do formulário
        driver.find_element(By.TAG_NAME, "button").click()

        #espera pela mensagem de sucesso aparecer
        sucesso = self.wait.until(EC.presence_of_element_located((By.XPATH, "//p/strong[contains(text(),'sucesso')]")))

        self.assertIn("sucesso", sucesso.text.lower())

if __name__ == "__main__":
    unittest.main()
