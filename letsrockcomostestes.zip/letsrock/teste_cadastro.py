import unittest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager


class TestCadastroUsuario(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))
        cls.driver.maximize_window()
        cls.wait = WebDriverWait(cls.driver, 10)
        cls.base_url = "http://localhost/letsrock/cadastro.php"  

    @classmethod
    def tearDownClass(cls):
        cls.driver.quit()

    def test_cadastro_sucesso(self):
        driver = self.driver
        driver.get(self.base_url)

        #NOME
        nome_input = self.wait.until(EC.presence_of_element_located((By.NAME, "nome")))
        nome_input.send_keys("Usuário Teste")

        #DATA DE NASCIMENTO
        nascimento_input = driver.find_element(By.NAME, "nascimento")
        nascimento_input.send_keys("01/01/1990")

        #EMAIL
        email_input = driver.find_element(By.NAME, "email")
        email_input.send_keys("usuario.teste+selenium@example.com")

        #TELEFONE
        telefone_input = driver.find_element(By.NAME, "telefone")
        telefone_input.send_keys("11999999999")

        #SENHA
        senha_input = driver.find_element(By.NAME, "senha")
        senha_input.send_keys("senha123")

        #submit no formulário
        driver.find_element(By.CLASS_NAME, "submit-btn").click()

        #espera para redireionamento ate a tela de login
        self.wait.until(EC.url_contains("login.php"))

        #mensagem de sucesso (se existir)
        self.assertIn("login.php", driver.current_url)


if __name__ == "__main__":
    unittest.main()
