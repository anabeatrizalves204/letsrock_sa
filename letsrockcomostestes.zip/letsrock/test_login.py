import unittest
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager


class TestLoginUsuario(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        #inicializa o navegador
        cls.driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))
        cls.driver.maximize_window()
        cls.base_url = "http://localhost/letsrock/login.php"
        cls.wait = WebDriverWait(cls.driver, 10)

    def test_login_sucesso(self):
        self.driver.get(self.base_url)

        #espera pelo campo email
        self.wait.until(EC.presence_of_element_located((By.NAME, "email")))

        #preenche os campos de login, de um usuário válido no banco
        email_input = self.driver.find_element(By.NAME, "email")
        senha_input = self.driver.find_element(By.NAME, "senha")
        email_input.send_keys("teste@exemplo.com")
        senha_input.send_keys("senha123")

        #botão
        self.driver.find_element(By.CLASS_NAME, "submit-btn").click()

        #verifica se tem alerta js
        try:
            alert = self.wait.until(EC.alert_is_present())
            alert_text = alert.text
            alert.accept()
            self.assertIn("sucesso", alert_text.lower())
        except:
            self.fail("Alerta de login não apareceu!")

    def test_login_falha(self):
        self.driver.get(self.base_url)

        self.wait.until(EC.presence_of_element_located((By.NAME, "email")))

        email_input = self.driver.find_element(By.NAME, "email")
        senha_input = self.driver.find_element(By.NAME, "senha")
        email_input.send_keys("email_invalido@teste.com")
        senha_input.send_keys("senha_errada")

        self.driver.find_element(By.CLASS_NAME, "submit-btn").click()

        #espera pela mensagem de erro na tela
        try:
            erro_div = self.wait.until(
                EC.presence_of_element_located((By.CLASS_NAME, "mensagem.erro"))
            )
            self.assertIn("incorretos", erro_div.text.lower())
        except:
            self.fail("Mensagem de erro não apareceu na tela!")

    @classmethod
    def tearDownClass(cls):
        #espera 5 segundos antes de fechar o navegador
        time.sleep(5)
        cls.driver.quit()


if __name__ == "__main__":
    unittest.main(verbosity=2)
